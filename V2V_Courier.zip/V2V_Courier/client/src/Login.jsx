
function Login()
{
return(
<div>
    <p> Login page</p>
</div>

)
}
export default Login;