import React from 'react'
function Home()
{
    return(
        <h2> home component</h2>
    )
}
export default Home;